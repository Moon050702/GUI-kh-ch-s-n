package quanlykhachsan;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GUI_qlks extends javax.swing.JFrame {

    DefaultTableModel da;
    Khachsan ks;

    public GUI_qlks() {
        initComponents();
        moaw();
    }

    public void moaw() {
        da = (DefaultTableModel) tbl_table.getModel();
        tbl_table.setModel(da);
        ks = new Khachsan();
    }

    public void napvaodata(Phong n) {
        da.addRow(new Object[]{n.getHoTen(), n.getTuoi(), n.getCmnd(), n.getLoaiPhong(), n.getSoNgayThue(), n.getGiaThue()});
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_ten = new javax.swing.JTextField();
        txt_tuoi = new javax.swing.JTextField();
        txt_cmnd = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btn_doc = new javax.swing.JButton();
        btn_tinhtien = new javax.swing.JButton();
        btn_thoat = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_table = new javax.swing.JTable();
        txt_xoa = new javax.swing.JButton();
        btn_nhap = new javax.swing.JButton();
        cb_loai = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        txt_ngaythue = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        btn_dem = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel1.setText("Tuổi");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel2.setText("Họ tên ");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel3.setText("Số CMND");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel4.setText("          Quản lí khách sạn");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel5.setText("  Thông tin khách hàng");

        txt_ten.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        txt_tuoi.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        txt_cmnd.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        jLabel6.setBackground(new java.awt.Color(255, 204, 204));
        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel6.setText("Loại Phòng");

        btn_doc.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        btn_doc.setText("Hiện danh sách");
        btn_doc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_docActionPerformed(evt);
            }
        });

        btn_tinhtien.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        btn_tinhtien.setText("Tính tiền");
        btn_tinhtien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tinhtienActionPerformed(evt);
            }
        });

        btn_thoat.setBackground(new java.awt.Color(255, 51, 102));
        btn_thoat.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        btn_thoat.setForeground(new java.awt.Color(255, 255, 255));
        btn_thoat.setText("Thoát");
        btn_thoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_thoatActionPerformed(evt);
            }
        });

        tbl_table.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tbl_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Họ tên", "Tuổi", "CMND", "Loại phòng", "Ngày thuê", "Tính tiền"
            }
        ));
        jScrollPane1.setViewportView(tbl_table);

        txt_xoa.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        txt_xoa.setText("Xóa khách hàng");
        txt_xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_xoaActionPerformed(evt);
            }
        });

        btn_nhap.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        btn_nhap.setText("Thêm");
        btn_nhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nhapActionPerformed(evt);
            }
        });

        cb_loai.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        cb_loai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A", "B", "C" }));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel7.setText("Ngày thuê");

        txt_ngaythue.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        txt_ngaythue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_ngaythueActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton1.setText("Lưu");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btn_dem.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        btn_dem.setText("Đếm khách ");
        btn_dem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_demActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel7)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cb_loai, javax.swing.GroupLayout.Alignment.TRAILING, 0, 330, Short.MAX_VALUE)
                            .addComponent(txt_ngaythue, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txt_cmnd, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txt_tuoi, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txt_ten, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(btn_dem)
                        .addGap(18, 18, 18)
                        .addComponent(btn_tinhtien, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_nhap, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(256, 256, 256)
                        .addComponent(jLabel8)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1)
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txt_xoa, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(btn_doc)
                .addGap(29, 29, 29)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(175, 175, 175)
                .addComponent(btn_thoat, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 527, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(513, 513, 513))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jLabel4)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txt_ten, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_tuoi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_cmnd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_ngaythue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cb_loai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_dem)
                            .addComponent(btn_tinhtien)
                            .addComponent(btn_nhap))
                        .addGap(18, 18, 18)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_thoat)
                    .addComponent(jButton1)
                    .addComponent(btn_doc)
                    .addComponent(txt_xoa))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
public void inds() {
        xoabang();
        for (Phong p : ks.a) {
            napvaodata(p);
        }
    }

    public void xoabang() {
        int n = tbl_table.getRowCount();
        for (int i = n; i > 0; i--) {
            da.removeRow(i - 1);
        }
    }
    private void btn_thoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_thoatActionPerformed
        int i = JOptionPane.showConfirmDialog(null, "Bạn có muốn thoát không", "Thông báo", JOptionPane.YES_NO_OPTION);
        if (i == JOptionPane.YES_OPTION) {
            dispose();
        }
    }//GEN-LAST:event_btn_thoatActionPerformed
    ArrayList<Phong> Adoc;

    private void btn_docActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_docActionPerformed
        ks.docfile("DocFile.txt");

        inds();


    }//GEN-LAST:event_btn_docActionPerformed

    private void btn_tinhtienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tinhtienActionPerformed
        String cmnd = JOptionPane.showInputDialog(null, "Nhập CMND cần tìm");
        if (ks.timcmnd(cmnd) != null) {
            xoabang();
            napvaodata(ks.timcmnd(cmnd));
        } else {
            JOptionPane.showMessageDialog(null, "Không có khách");
        }
    }//GEN-LAST:event_btn_tinhtienActionPerformed

    private void txt_xoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_xoaActionPerformed
        String cmnd = JOptionPane.showInputDialog(null, "Nhập CMND cần xóa");
        if (ks.XoaTheoCMND(cmnd)) {
            inds();
        } else {
            JOptionPane.showMessageDialog(null, "Không có CMND trùng khớp");
        }
    }//GEN-LAST:event_txt_xoaActionPerformed

    private void btn_nhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_nhapActionPerformed
        String hoten = txt_ten.getText();
        int tuoi = Integer.parseInt(txt_tuoi.getText());
        String cmnd = txt_cmnd.getText();
        String loai = cb_loai.getSelectedItem().toString();
        int songaythue = Integer.parseInt(txt_ngaythue.getText());
        Phong p = new Phong(hoten, tuoi, cmnd, loai, songaythue);
        ks.themMoi(p);
        napvaodata(p);
    }//GEN-LAST:event_btn_nhapActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    ks.ghifile("thaonguyen");

    }//GEN-LAST:event_jButton1ActionPerformed

    private void btn_demActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_demActionPerformed
        ks.dem();

    }//GEN-LAST:event_btn_demActionPerformed

    private void txt_ngaythueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_ngaythueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_ngaythueActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI_qlks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI_qlks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI_qlks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI_qlks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI_qlks().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_dem;
    private javax.swing.JButton btn_doc;
    private javax.swing.JButton btn_nhap;
    private javax.swing.JButton btn_thoat;
    private javax.swing.JButton btn_tinhtien;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cb_loai;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_table;
    private javax.swing.JTextField txt_cmnd;
    private javax.swing.JTextField txt_ngaythue;
    private javax.swing.JTextField txt_ten;
    private javax.swing.JTextField txt_tuoi;
    private javax.swing.JButton txt_xoa;
    // End of variables declaration//GEN-END:variables
}
