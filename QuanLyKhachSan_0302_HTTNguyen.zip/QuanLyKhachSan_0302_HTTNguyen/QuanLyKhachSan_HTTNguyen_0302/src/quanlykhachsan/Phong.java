package quanlykhachsan;

public class Phong extends Nguoi {

    String loaiPhong;
    int soNgayThue;

    public Phong() {
    }

    public Phong(String hoTen, int tuoi, String cmnd, String loaiPhong, int soNgayThue) {
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.cmnd = cmnd;
        this.soNgayThue = soNgayThue;
        this.loaiPhong = loaiPhong;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public int getTuoi() {
        return tuoi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

    public String getCmnd() {
        return cmnd;
    }

    public void setCmnd(String cmnd) {
        this.cmnd = cmnd;
    }

    public String getLoaiPhong() {
        return loaiPhong;
    }

    public void setLoaiPhong(String loaiPhong) {
        this.loaiPhong = loaiPhong;
    }

    public int getSoNgayThue() {
        return soNgayThue;
    }

    public void setSoNgayThue(int soNgayThue) {
        this.soNgayThue = soNgayThue;
    }

    public double getGiaThue() {
        if (getLoaiPhong().equalsIgnoreCase("A")) {
            return 500 * soNgayThue;
        } else if (getLoaiPhong().equalsIgnoreCase("B")) {
            return 300 * soNgayThue;
        } else {
            return 100 * soNgayThue;
        }
    }

    @Override
    public String toString() {
        return super.toString() + soNgayThue + loaiPhong + getGiaThue();
    }

}
