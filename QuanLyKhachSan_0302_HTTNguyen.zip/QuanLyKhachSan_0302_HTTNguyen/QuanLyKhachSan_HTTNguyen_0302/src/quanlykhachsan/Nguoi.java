package quanlykhachsan;

public class Nguoi {

    String hoTen, cmnd;
    int tuoi;

    public Nguoi() {
    }

    public Nguoi(String hoTen, int tuoi, String cmnd) {
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.cmnd = cmnd;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public int getTuoi() {
        return tuoi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

    public String getCmnd() {
        return cmnd;
    }

    public void setCmnd(String cmnd) {
        this.cmnd = cmnd;
    }

    @Override
    public String toString() {
        return "Nguoi{" + "hoTen=" + hoTen + ", cmnd=" + cmnd + ", tuoi=" + tuoi + '}';
    }

}
