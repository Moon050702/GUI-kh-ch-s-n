package quanlykhachsan;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Khachsan {

    ArrayList<Phong> a = new ArrayList<>();

    public void themMoi(Phong n) {
        a.add(n);
    }

    public boolean XoaTheoCMND(String cmnd) {
        for (Phong p : a) {
            if (cmnd.equalsIgnoreCase(p.getCmnd())) {
                a.remove(p);
                return true;
            }
        }
        return false;
    }

    public Phong timcmnd(String cmnd) {
        for (Phong p : a) {
            if (p.getCmnd().equalsIgnoreCase(cmnd)) {
                return p;
            } 
        }
        return null;
    }

    public void docfile(String tenfile) {
        a = new ArrayList<>();
        try {
            FileReader fr = new FileReader(tenfile);
            BufferedReader bf = new BufferedReader(fr);
            String line = "";
            while (true) {
                line = bf.readLine();
                if (line == null) {
                    break;
                }
                String s[] = line.split(",");
                String hoten = s[0];
                int tuoi = Integer.parseInt(s[1]);
                String cmnd = s[2];
                String loaiphong = s[3];
                int ngaythue = Integer.parseInt(s[4]);
                Phong p = new Phong(hoten, tuoi, cmnd, loaiphong, ngaythue);
                themMoi(p);
            }
            fr.close();
            bf.close();
        } catch (Exception e) {
            System.out.println("Lỗi đọc file");
        }
    }

    public void ghifile(String tenfile) {
        try {
            FileWriter fw = new FileWriter(tenfile);
            BufferedWriter bw = new BufferedWriter(fw);
            for (Phong p : a) {
                bw.write(p.toString());
                bw.newLine();
            }
            bw.close();
            fw.close();
        } catch (Exception e) {
        }
    }

    public void dem() {
        int k = 0;
        for (Phong p : a) {
            k++;
        }
        JOptionPane.showMessageDialog(null, "Số khách đã thuê " + k);
    }

    public void sapxep() {
        for (int i = 0; i < a.size() - 1; i++) {
            for (int j = i + 1; j < a.size(); j++) {
                if (a.get(i).getGiaThue() > a.get(j).getGiaThue()) {
                    Phong temp = a.get(i);
                    a.set(i, a.get(j));
                    a.set(j, temp);
                }
            }
        }

    }

    public void sapxepgiam() {
        for (int i = 0; i < a.size() - 1; i++) {
            for (int j = i + 1; j < a.size(); j++) {
                if (a.get(i).getGiaThue() < a.get(j).getGiaThue()) {
                    Phong temp = a.get(i);
                    a.set(i, a.get(j));
                    a.set(j, temp);
                }
            }
        }

    }

    public void inds() {
        for (Phong p : a) {
            System.out.println(p.toString());
        }
    }
}
